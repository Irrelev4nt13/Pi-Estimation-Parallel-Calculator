#pragma once
long long int monte_carlo(long long int, long long int, int);